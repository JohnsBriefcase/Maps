Here's how to install everything.

There will be three folders in the tf folder there, first one custom, go all the way to the popfiles and place them in your tf/custom/pop/scripts/population folder in Team Fortress 2.
Next is maps, place the bsp and nav file there in your tf/maps folder in Team Fortress 2.
Last is materials where you'll go find the vtf and vmt files, place them in your tf/materials/hud folder in Team Fortress 2.
If you do not have any of the folders listed above, simply create those folders.

And that is all you have to do for installion

To those who want to create custom missions on this map:

There's a few thing to know
Spawns:
Left_Spawn (spawn with larger door, bear in mind that only giants can spawn here}
Right_Spawn (spawn with smaller door}
Tank_Spawn (with boss_path_01 as starting path)
Sniper_Spawn
Spy_Spawn
Engineer_Spawn

For Engineer bots, make sure you give them a custom template to accomodate for these custom spawn names.
So for instance, you would write TeleportWhere Left_Spawn.

And that is all you need to know.