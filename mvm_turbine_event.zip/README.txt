For installation of this map, please follow these directions.

In the tf folder is three different folders.  Each contains stuff for the map to work.
For the first folder, you'll find the two popfiles required for this map.  Place those two in your tf/custom/pop/scripts/population folder in Team Fortress 2.
For the second folder, you'll find the bsp and nav file.  Place those in your tf/maps folder in Team Fortress 2.
For the last folder, it holds the vmt and vtf files needed for a custom icon.  Place those in your tf/materials/hud folder in Team Fortress 2.

If you don't have any of the folders in your game directory listed above, just create those folders.

For those who want to create custom missions:

Here's a list of spawns:
Left_Spawn (spawn with the larger door, this is the only spawn giants can fit through)
Right_Spawn (spawn with smaller door, don't spawn giants here, stuff like steel gauntlets work though)
Tank_Spawn (boss_path_1 is beginning path)
Sniper_Spawn
Spy_Spawn
Engineer_Spawn (make sure you make a custom template for this to accomodate for the custom spawn names, for instance you would write TeleportWhere Left_Spawn)
